# TempMail

*URL*: http://kindamail.pw/cpanel
*username*: kindfbom
*password*: Lxic3oc6tgpl

## Creating Emails via API

### Authorize
https://kindamail.pw:2083/login/?login_only=1&user=kindfbom&pass=Lxic3oc6tgpl

### Create Email
https://kindamail.pw:2083/cpsess0563959027/execute/Email/add_pop?email=safeer&domain=kindamail.pw&password=Q30f3OLKvyrJ7&quota=20&send_welcome_email=0
