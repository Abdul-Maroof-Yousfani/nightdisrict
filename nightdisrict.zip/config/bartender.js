export default {
    "type": "service_account",
    "project_id": "bartenderapp-349ac",
    "private_key_id": "783536b0c82e2406eb64748dff00ec9243a2c32e",
    "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCOvr72xLY6tahR\nSDKqlgAOoEaHib19ySw6RUxtJnUtpltZdxZ6ckIoSblSf18SdlfU+ElQ+xySTzYO\neHLhcXbAEb8S6zIixAJMkzjSRxF83haN+KC0feHxX9IOEPijGG+Tnq8flNjyEqy/\nobwSl/uFgop5Padc/bxbQd8PAK7iP3Aa7cprGoVzPJ3zJl4xnZkWWg7DLq1CqJCX\ns8A9uAvthK9w/z/5AroKRTwXWM+AVx5z3KhMR2UgZKFZ2xEl+JQufjWcvDa3Ayif\n8bPpF0EdC19v9Lu3lXUNovv2DEyJV8BvjV4Gvizf0fZXNZW/TOhyRT+PsB/m0KME\ntEqW7OxNAgMBAAECggEAASyZ1FohuZV/z1JXb1YsQNRuFb6KE4m6AHsGBe6KhEhL\nE4KSnnDJ4YgUJ35U1ayVhhYOOolgeQ5sSHaQEi/OI1aiCJS9Fo67fYVlVfCzlaU5\nxfA946zzk38iLts5LWYMZ1nekzcZQDxK9Ez0Put/qv3fI3vPB2UQoZBKtoN/qQXH\nzDyt+lEpSdevdk26TyhgJ3L/qyjU9tQjmD31o7ULa1d2Sj0ocfDlLrXlppgVZvpC\n6mv8fflCrVzV9qO247CJjfvq/PTXtrd4P0wQVDGhhCQjDWjLKDe3U/jAFNUYink2\n8xs04QJK3eHeLD+mi4oex1WocB84cqD9AdtVohufwwKBgQDCMlpZ7tRnMUqixqXQ\nKLNBfI5EyfkSUxlcXIJWTG9HHJDNecCvIVrYK3iLK5DaVUgPPmKd1bo0FZ0MbNF9\no1CfKqCKv0mx8L9TJlDCtoqzIqnDZMygeuBSPKfNWr7h9Ap3If88HHvq8tjax7D3\nwoLOmBjCUzA9gfzcjAq0kKY8twKBgQC8LIPE++OSetHUgFh4A0+XJIuOqX0hDIq7\n4hNOqVD3sa6q74zhnU4thdU4eo5BOm7BwKXDm2yM2tYEZPicpLjvn4tJvKop9blo\nDUFPYF5jkCsau/+NtvIy5niNV/OF/CjhOME+H2h8n2wn0awjPncEaXUiWXvY990T\n1Jl1pSSjGwKBgDLoOD8zGIMkrMgXAwiaYsNb/3+Q4rYnCpLnvVMaHmGp31u9+wDt\n4X6hhqwU85gImydD115A1Nsqf0zuicxBr7TJ2+QDWTJIRh9p/+nLKHjlMVODbRD0\npTFprSNsEnXxH30zcFE1tlZU6vwPNRj96IR34qWuYQr+tGasX3IOKUXpAoGBALUX\nKeCCgKnRJOoacgldNlVASEYM+my5wzG5CdejvlYBWxUJ4EyntDq/F0l5ODmx4DD6\nEwzCIJ8VYu1rto4ZQBjrM4LM2/3xinKGfxnCplOuxKy/y9o3+7Hcdpufzq5c04Kb\nueztEQMN8WoIsF5imOtYCe/6qeNN9iZFbUH4od+NAoGACnARu7key7YtZUGg8FFm\nd9F+1b69V3X3IQRpGHfp4FgFuAzcgBdkVR9Aj/jSxurKV1DFXVFM5hYyqtwte6Ia\nMcOzEeaqe8bdD8A+VO36Ih/Mj+9H+RIgQaA5aSjVgTLEBSTdfi+zuRtGnOyF44rG\n8cR+iAgI4mOd7+bZ1mOtQWU=\n-----END PRIVATE KEY-----\n",
    "client_email": "webhook-service@bartenderapp-349ac.iam.gserviceaccount.com",
    "client_id": "113937056991772199584",
    "auth_uri": "https://accounts.google.com/o/oauth2/auth",
    "token_uri": "https://oauth2.googleapis.com/token",
    "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
    "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/webhook-service%40bartenderapp-349ac.iam.gserviceaccount.com",
    "universe_domain": "googleapis.com"
  }
  