export default {
    "type": "service_account",
    "project_id": "fitech33-b944b",
    "private_key_id": "bdadeaa60847c07129fff07cd04c021dbc7c1393",
    "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQC2cagw4xHNzsue\nabV4DmTclkPuxIguYLuC1PCtd6HYIjcfumWe9SRpfDEbvO+O/nbI2p1EnG4XPIpU\n18+L4iq5MNKhsa1ROhLSMt8UoMtvYvSRu3xBKYe5/FYLFDvPAKxvyswwLYHMX9w7\nyZhEcsJZCyHVgU13+01kxnUqWtJSIfY2aibc7/dGpPyKforjAzRZnuOyImcqKW3a\nxF8Z/55D9A2calP8/+pILprMo3ycX5iFBta3mhjUqHpqxchGT+B4Ct9VRJJfWEpA\nEohhTMIvhoRzrEWL/Uf4DjCkTkNCnx7FQ4UwgNK0xxyVbnGxtV672IGKOToalHKP\n0Vf9svx/AgMBAAECggEAVzKtW2g7yyzqXvVRGWdvx4o+P7FJETmEhXx258HE5cM8\nq3pwNXAfDhegdQxxRtvSNB9giTlm2M5Do1deSBI5rzdphISiPK9P7Y0I2BgeA0e9\ncqW0NoS97SNwkG0EROSihe/cda5aWi762Mx6bUSYJOzQJ/Zb61t92wuLVkoAOeZW\n7jFAU5LWNyAjgfbde2uJPwCkKOjZSH8uavIAuGXZpuhdt2pXXLJ1KjMCV8pBYyXK\nOWts+kVX8Z3zw7ERHqP5EH9U0IeAxAAFHlxMd1HV+x8ZYpTj2/xQIHe4BNW3pCMA\nvyxvIxAoR2qQXOHZMcqpbM0oedf9/5IdhneupGyPaQKBgQD4Su9gaXjJbQTS/bcU\nE+OFI/dHJbXWzjA47KlvQu5xd5GbsBjmBUhcAafM7f3I7j1uQc2+T7dt35lXH/a9\nlyQPxmN1bX3pJD82r1qLHL1q/IUTfVVpvhSrvV75zGgx0qlLBGVpBAc/X7iw7QZ0\nccEoXS+yJyqdtZlx12OamFYcuwKBgQC8G3P8yTTIvDVcmvCUDr3VOb36vJ6hKwnY\n9ZaSOW55/DydngVqSAaGBg6ocpafFMii0ccawxeq19maKXLFab/tU/b1Q0TluxRL\nV6CmH4rX0ycyKgwKSvgUppFtnRjG8UZhWxKT3KXQC0n4W+XcDe3DHqtAZMtIpnX8\n6k5lVP2lDQKBgBRTZhc5aybqIsv28ybUnfqHQDX101X7WR0/2nr+OrDVPflFyDQE\nWLEXfZocHXt2bVb6UhJzSivXcyEbv8IzfkNAVWIGjZkpW3dpkXrz5lm8xFQdHYHj\niqOog/7lCd6SRUOb34ViTAmXF3J8ZNvheBOK1V27MRTqCd606DV+pQYDAoGATDU3\nFWeSqeyOFdlztBgQ0mzVSdrWzWa5U5uTh+QanPMSv6yAdyF8+xlDIP1jhkmOS2B/\nsJjvYriWIP2/0LjaF9VXjN/W7tePDkMPA55tyqhyDcG5JQZgYUVmT6lAm4CuSczy\nxtKynomkSyk4A6Hk/JLVQH5VWTaPQIrQff8jz5UCgYEA2Na4sCh9pHgMFDf+dhcx\nxiqDk2ZdmTqMDysoeegIRcbGyIQFzr573s3ZELQRMNE9B1cdRrJHxY1FgoLF4ChR\nQ3JMZ39yvyfEqQfaQxStpBVWB+0Ml+gKn7fc32IAREdaE/54bUvl9cHVCsOKzJfE\nHsztmVZ2wahjtXY/uKPGFhw=\n-----END PRIVATE KEY-----\n",
    "client_email": "purchase-serviceaccount@fitech33-b944b.iam.gserviceaccount.com",
    "client_id": "113839079520154539859",
    "auth_uri": "https://accounts.google.com/o/oauth2/auth",
    "token_uri": "https://oauth2.googleapis.com/token",
    "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
    "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/purchase-serviceaccount%40fitech33-b944b.iam.gserviceaccount.com",
    "universe_domain": "googleapis.com"
  }
  