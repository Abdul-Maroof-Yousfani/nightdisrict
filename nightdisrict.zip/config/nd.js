export default {
  "type": "service_account",
  "project_id": "night-district-1",
  "private_key_id": "cd49cd50acb88748e62f81e1a05401863682b510",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDR5YFZ+2Za4/1g\n7oYGMZj0KJWa98RXuD9L8O5/+TZHsett0VyPcG8jY5SDWNlv7QcjoIL48cAQpUlb\n4wRbz9/2vY5DVMy8nUYrvbM7AIs+r2CE/wXSJV7tWs6sdQaOVD0CM/02RwosTitE\nCr/5ZbTzE3+GpwWRA4LnnVeWqwyOOIcHwEwcK3WYseZiM8wTw9mSjq3rxf4qOC1f\n7U+5oQyPusE9xwNpO0iwsu+9jnahjYF8BWmlouXtQ+ck2k5LJ5cDl9XW+zRSHAgR\nzMNdTO8oJcFlQrDHqrcmTe0+3oBfqyn1RBXSf94k5m+AMap7DaT5q9pyFWl3VoOM\nB+WFyQZBAgMBAAECggEAAMqo0HPpCwgcXxEFkdzOa+Ln10sr3yTd03+naSBMUd8i\nJ9vTQY4yqPF/vG1K5Dvv8pdblhnMkVLWbuDhbdvtTKQX8bw2VwKQzVJ+dFyLnJEx\nvqeq9BvV1An98NRinv8y0T/HTWeSv9J3ccmIokL9s0Y06p9AX1zctGVIGMHI9Z56\nWvDZEd9TI8Amf6mGcCoQrSHMJb2ysH8BJBcSDLMBOqhqpZRiDbo4w6iSzRKwaic1\n2vq7jasCVzd4C6vHWvG7rckqhta76e5ik2QS15P+Elunlpbb/oBF5uNrlObu4Tfn\nuddKTR1ay3VbGd8WtlQY53JCfch6cUOoVk2DWIZ/4QKBgQDz3gUO1bQm8utHXjgU\nuDTBD2KOwE0tlULvqgFuTxyCiotzffB1xHv1tlp1TcJzQMTXkidZwX2S8/p5wa3V\nQ612YpboXe50QFCkaTntNr5GliSqCbiVIDxszPjCdkmvKeYCCIve3xdUjBYldCOT\n44F9ZdLBv5FSPRyk8YiOf25/YQKBgQDcVtJkJ8YrXd9OVBAnUYs51rwbVRpbq8Td\nHtYPzsXRpi51o2lzmrsgDQQUI7+N8mgkHMM9gr9PWjEmuponWF0pjY++302ABQ5/\nTda5d/+OTd359xlYviT0JMLc9371ii+spgyNUGUJ6iHdNvrlK1pUbx2+UinAblP1\nfp0BY55S4QKBgBaYI2/UbPSO3S2nlRqWVozsl/0R5BStF56M6cUGn2WY4IK60GSY\n58NEOe1UXwe+oH44lFzEiJXs9PAC+dAgjRnC2Kh+y3EJ5G7XMP7Ba6+uiYcXj3qB\nmheahhG+U+VexGi70fm8QbUbpZGiyQkSsxSjMnuw/A3ai6TcnAJX3C0BAoGBAMcF\nNSx6MKljNRzPGXgqU5N+vpIBoLlEwaDpBXlpz4y6iiR/4fQlwvgESbbXQ2K3nhFg\nWYnp21uVn+fXjP4U9rFdyIUjtiD4cEvUxyrnlNG4y9PIugBKX56WxdxJQUgP9VgA\n9D2AbIM0FDp4Os9dBU5Wv4r1M/k4rmWEY9SpYoyBAoGBAI274oOS6sRaJrqNQAy1\nJ5YOHfC290jeFvetPEfuQ3CPmh30l6bgACgIGiawPrZX5ShBM4mLcSDOp4OhxEU3\niHKDwUX2/q06HIRQUkoPGX8BzH0iEn+oghJoJu31x90YiRIVkx85H0MruvOZP1Ub\n57lYz+OwPEjEnBieSqvFE7fU\n-----END PRIVATE KEY-----\n",
  "client_email": "firebase-adminsdk-06srf@night-district-1.iam.gserviceaccount.com",
  "client_id": "110561631095988907938",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-06srf%40night-district-1.iam.gserviceaccount.com",
  "universe_domain": "googleapis.com"
}
  